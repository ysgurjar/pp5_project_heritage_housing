import * as Heroku from '@heroku-cli/schema';
export declare const printGroups: (teams: Heroku.Team[], type: {
    label: string;
}) => void;
export declare const printGroupsJSON: (teams: Heroku.Team[]) => void;
