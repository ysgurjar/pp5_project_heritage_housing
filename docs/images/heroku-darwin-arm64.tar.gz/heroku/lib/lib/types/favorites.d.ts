export declare type Favorite = {
    id: string;
    resource_id: string;
    resource_name: string;
    type: string;
};
export declare type Favorites = Favorite[];
