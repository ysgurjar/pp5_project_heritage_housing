import { Hook } from '@oclif/core';
declare const version: Hook.Init;
export default version;
