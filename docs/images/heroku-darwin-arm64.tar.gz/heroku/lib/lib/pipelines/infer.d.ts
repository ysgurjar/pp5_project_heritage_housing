export default function infer(app: string): string[];
