import { PrivateSpacesVpn } from '@heroku-cli/schema';
export declare function displayVPNConfigInfo(space: string, name: string, config: PrivateSpacesVpn): void;
