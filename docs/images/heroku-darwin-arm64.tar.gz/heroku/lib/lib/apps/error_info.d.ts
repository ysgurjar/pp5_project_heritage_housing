export declare type ErrorInfo = {
    name: string;
    title: string;
    level: string;
};
declare const ERROR_INFO: ErrorInfo[];
export default ERROR_INFO;
