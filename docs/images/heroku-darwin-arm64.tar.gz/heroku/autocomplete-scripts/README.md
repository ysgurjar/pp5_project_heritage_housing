Autocomplete Scripts
==========

This directory contains the scripts that are used to point shells to autocomplete caches for the Heroku CLI.

## Why here?
So they are included in the final NPM package and accurately referenced after TS->JS compilation.
